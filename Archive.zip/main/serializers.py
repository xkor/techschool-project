from rest_framework import serializers
from .models import Customer
from datetime import date


class CustomerSerializer(serializers.ModelSerializer):
    age = serializers.SerializerMethodField()

    class Meta:
        model = Customer
        fields = '__all__'

    @staticmethod
    def get_age(obj):
        today = date.today()
        age = today.year - obj.date_of_birth.year - (
                (today.month, today.day) < (obj.date_of_birth.month, obj.date_of_birth.day)
        )
        return age
