from django.urls import path
from .views import CustomerView, CustomerUpdateView


urlpatterns = [
    path('customer/', CustomerView.as_view()),
    path('customer/<int:pk>/', CustomerUpdateView.as_view())
]
