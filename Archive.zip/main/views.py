from rest_framework import views, response, generics,  validators, status
from .serializers import CustomerSerializer
from .models import Customer


class CustomerView(views.APIView):
    def get(self, request):
        pass

    def post(self, request):
        pass

